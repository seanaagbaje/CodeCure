document.addEventListener('DOMContentLoaded', () => {
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    const saveSnippetButton = document.getElementById('saveSnippet');
    const savedSnippetsSelect = document.getElementById('savedSnippets');
    const languageSelect = document.getElementById('language');
    const codeTextarea = document.getElementById('code');

    mobileMenuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });

    // Close mobile menu when clicking outside
    document.addEventListener('click', (event) => {
        if (!mobileMenu.contains(event.target) && !mobileMenuButton.contains(event.target)) {
            mobileMenu.classList.add('hidden');
        }
    });

    // Save snippet functionality
    saveSnippetButton.addEventListener('click', () => {
        const language = languageSelect.value;
        const code = codeTextarea.value;
        if (code.trim() !== '') {
            const snippetName = prompt('Enter a name for this snippet:');
            if (snippetName) {
                const snippet = { name: snippetName, language, code };
                let snippets = JSON.parse(localStorage.getItem('codeSnippets') || '[]');
                snippets.push(snippet);
                localStorage.setItem('codeSnippets', JSON.stringify(snippets));
                updateSavedSnippetsDropdown();
            }
        } else {
            alert('Please enter some code before saving a snippet.');
        }
    });

    // Load saved snippet
    savedSnippetsSelect.addEventListener('change', () => {
        const selectedSnippetName = savedSnippetsSelect.value;
        if (selectedSnippetName) {
            const snippets = JSON.parse(localStorage.getItem('codeSnippets') || '[]');
            const selectedSnippet = snippets.find(s => s.name === selectedSnippetName);
            if (selectedSnippet) {
                languageSelect.value = selectedSnippet.language;
                codeTextarea.value = selectedSnippet.code;
                // Show delete button
                document.getElementById('deleteSnippet').style.display = 'inline-block';
            }
        } else {
            // Hide delete button if no snippet is selected
            document.getElementById('deleteSnippet').style.display = 'none';
        }
    });

    // Delete saved snippet
    function deleteSnippet(snippetName) {
        let snippets = JSON.parse(localStorage.getItem('codeSnippets') || '[]');
        snippets = snippets.filter(s => s.name !== snippetName);
        localStorage.setItem('codeSnippets', JSON.stringify(snippets));
        updateSavedSnippetsDropdown();
        console.log(`Snippet "${snippetName}" deleted`); // Added logging
    }

    // Update saved snippets dropdown
    function updateSavedSnippetsDropdown() {
        const snippets = JSON.parse(localStorage.getItem('codeSnippets') || '[]');
        savedSnippetsSelect.innerHTML = '<option value="">Select a saved snippet</option>';
        snippets.forEach(snippet => {
            const option = document.createElement('option');
            option.value = snippet.name;
            option.textContent = `${snippet.name} (${snippet.language})`;
            savedSnippetsSelect.appendChild(option);

            // Add delete button
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.className = 'ml-2 px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600';
            deleteButton.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation(); // Prevent the dropdown from closing
                if (confirm(`Are you sure you want to delete the snippet "${snippet.name}"?`)) {
                    deleteSnippet(snippet.name);
                }
            };
            savedSnippetsSelect.appendChild(deleteButton);
        });
    }

    // Initial population of saved snippets dropdown
    updateSavedSnippetsDropdown();

    // Delete snippet functionality
    document.getElementById('deleteSnippet').addEventListener('click', () => {
        const selectedSnippetName = savedSnippetsSelect.value;
        if (selectedSnippetName && confirm(`Are you sure you want to delete the snippet "${selectedSnippetName}"?`)) {
            deleteSnippet(selectedSnippetName);
            savedSnippetsSelect.value = '';
            languageSelect.value = '';
            codeTextarea.value = '';
            document.getElementById('deleteSnippet').style.display = 'none';
        }
    });
});